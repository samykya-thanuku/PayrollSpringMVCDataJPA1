package com.cg.payroll.daoservices;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.payroll.beans.Associate;

public interface PayrollDAOServices extends JpaRepository<Associate,Integer> {

	/*int insertAssociate(Associate associate);

	boolean updateAssociate(Associate associate);

	Associate getAssociate(int associateId);

	List<Associate> getAssociates();

	boolean deleteAssociate(int associateId);
*/
}